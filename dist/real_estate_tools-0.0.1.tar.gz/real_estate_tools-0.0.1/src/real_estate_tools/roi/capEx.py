def capEx(rent: float, rate: float = .1):
    cap_ex = rent * rate
    return(cap_ex)