def calcTaxes(appraisal, tax_rate):
    taxes = appraisal * tax_rate/12
    return(taxes)