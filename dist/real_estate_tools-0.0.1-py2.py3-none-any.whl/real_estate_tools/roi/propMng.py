def propMng(rent: float, rate: float = .08):
    prop_mng = rent * rate
    return(prop_mng)